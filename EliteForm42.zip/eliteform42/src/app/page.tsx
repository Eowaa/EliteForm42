import Link from "next/link";
import Scene3D from "@/components/Scene3D";
import ProductCard from "@/components/ProductCard";
import { getFeaturedProducts } from "@/lib/products";
import { ArrowRight } from "lucide-react";

export default function HomePage() {
  const featured = getFeaturedProducts();

  return (
    <div className="relative">
      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-gold-900/20 via-transparent to-transparent pointer-events-none" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-12 pb-16 md:pt-20 md:pb-24">
          <div className="grid lg:grid-cols-2 gap-10 lg:gap-16 items-center">
            {/* Text */}
            <div className="order-2 lg:order-1 space-y-6">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-gold-500/30 bg-gold-500/5 text-xs font-medium text-gold-400">
                <span className="w-1.5 h-1.5 rounded-full bg-gold-400 animate-pulse" />
                Premium 3D-Druck
              </div>
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight leading-[1.1]">
                Humorvolle{" "}
                <span className="gold-text">3D-Kunst</span>
                <br />
                für echte Kenner
              </h1>
              <p className="text-lg text-gray-400 max-w-lg leading-relaxed">
                EliteForm42 fertigt hochwertige, 3D-gedruckte Schilder und Figuren
                mit einem Augenzwinkern. Schwarz. Gold. Und die Antwort auf alles.
              </p>
              <div className="flex flex-wrap gap-4 pt-2">
                <Link
                  href="/products"
                  className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-gold-500 text-dark-950 font-semibold text-sm hover:bg-gold-400 transition-colors shadow-gold"
                >
                  Zum Katalog
                  <ArrowRight className="w-4 h-4" />
                </Link>
                <Link
                  href="/products?category=Meme"
                  className="inline-flex items-center gap-2 px-6 py-3 rounded-full border border-gold-500/40 text-gold-400 font-medium text-sm hover:bg-gold-500/10 transition-colors"
                >
                  Memes entdecken
                </Link>
              </div>
            </div>

            {/* 3D Viewer */}
            <div className="order-1 lg:order-2">
              <Scene3D />
            </div>
          </div>
        </div>
      </section>

      {/* Featured */}
      <section className="border-t border-gold-500/10 bg-dark-900/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-20">
          <div className="flex items-end justify-between mb-10">
            <div>
              <h2 className="text-2xl md:text-3xl font-bold">
                Featured <span className="gold-text">Produkte</span>
              </h2>
              <p className="mt-2 text-sm text-gray-500">
                Unsere aktuellen Highlights – handverlesen und 3D-gedruckt.
              </p>
            </div>
            <Link
              href="/products"
              className="hidden sm:inline-flex items-center gap-1 text-sm text-gold-400 hover:text-gold-300 transition-colors"
            >
              Alle ansehen
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {featured.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>

          <div className="mt-10 text-center sm:hidden">
            <Link
              href="/products"
              className="inline-flex items-center gap-2 text-sm text-gold-400"
            >
              Alle Produkte ansehen
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* Categories teaser */}
      <section className="py-16 md:py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-2xl md:text-3xl font-bold text-center mb-10">
            Nach <span className="gold-text">Kategorie</span>
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { name: "Schilder", href: "/products?category=Schilder", desc: "Witze an der Wand" },
              { name: "Figuren", href: "/products?category=Figuren", desc: "Sammlerstücke" },
              { name: "Horror", href: "/products?category=Horror", desc: "Kosmischer Schrecken" },
              { name: "Meme", href: "/products?category=Meme", desc: "Internet-Klassiker" },
            ].map((cat) => (
              <Link
                key={cat.name}
                href={cat.href}
                className="group p-6 rounded-2xl bg-dark-900/50 gold-border hover:border-gold-500/50 hover:shadow-gold transition-all text-center"
              >
                <h3 className="text-lg font-semibold text-gray-100 group-hover:text-gold-300 transition-colors">
                  {cat.name}
                </h3>
                <p className="mt-1 text-xs text-gray-500">{cat.desc}</p>
              </Link>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
