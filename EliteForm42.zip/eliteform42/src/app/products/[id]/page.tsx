"use client";

import { useParams } from "next/navigation";
import Image from "next/image";
import Link from "next/link";
import { getProductById } from "@/lib/products";
import Scene3D from "@/components/Scene3D";
import { useCartStore } from "@/store/cart";
import { ShoppingCart, ArrowLeft, Check } from "lucide-react";
import { useState } from "react";

export default function ProductDetailPage() {
  const params = useParams();
  const id = params.id as string;
  const product = getProductById(id);
  const addItem = useCartStore((s) => s.addItem);
  const [added, setAdded] = useState(false);

  if (!product) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-20 text-center">
        <h1 className="text-2xl font-bold mb-4">Produkt nicht gefunden</h1>
        <Link href="/products" className="text-gold-400 hover:text-gold-300">
          Zurück zum Katalog
        </Link>
      </div>
    );
  }

  const handleAdd = () => {
    addItem(product);
    setAdded(true);
    setTimeout(() => setAdded(false), 2000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 md:py-14">
      {/* Back */}
      <Link
        href="/products"
        className="inline-flex items-center gap-2 text-sm text-gray-400 hover:text-gold-400 transition-colors mb-8"
      >
        <ArrowLeft className="w-4 h-4" />
        Zurück zum Katalog
      </Link>

      <div className="grid lg:grid-cols-2 gap-10 lg:gap-16">
        {/* Visuals */}
        <div className="space-y-6">
          <div className="relative aspect-square rounded-2xl overflow-hidden gold-border bg-dark-900">
            <Image
              src={product.image}
              alt={product.name}
              fill
              sizes="(max-width: 1024px) 100vw, 50vw"
              className="object-cover"
              priority
              unoptimized
            />
          </div>
          <Scene3D height="h-[320px] md:h-[380px]" />
        </div>

        {/* Info */}
        <div className="flex flex-col">
          <span className="inline-flex self-start px-3 py-1 text-xs font-semibold uppercase tracking-wider rounded-full bg-gold-500/10 text-gold-400 border border-gold-500/30 mb-4">
            {product.category}
          </span>
          <h1 className="text-3xl md:text-4xl font-bold tracking-tight">
            {product.name}
          </h1>
          <p className="mt-4 text-3xl font-bold gold-text">
            {product.price.toFixed(2).replace(".", ",")} €
          </p>
          <p className="mt-6 text-gray-400 leading-relaxed">
            {product.description}
          </p>

          {product.tags && product.tags.length > 0 && (
            <div className="mt-6 flex flex-wrap gap-2">
              {product.tags.map((tag) => (
                <span
                  key={tag}
                  className="px-2.5 py-1 text-xs rounded-md bg-dark-800 text-gray-400 border border-dark-700"
                >
                  {tag}
                </span>
              ))}
            </div>
          )}

          <div className="mt-10 space-y-4">
            <button
              onClick={handleAdd}
              className={`w-full flex items-center justify-center gap-2 px-6 py-4 rounded-full font-semibold text-sm transition-all ${
                added
                  ? "bg-green-600 text-white"
                  : "bg-gold-500 text-dark-950 hover:bg-gold-400 shadow-gold"
              }`}
            >
              {added ? (
                <>
                  <Check className="w-5 h-5" />
                  Hinzugefügt
                </>
              ) : (
                <>
                  <ShoppingCart className="w-5 h-5" />
                  In den Warenkorb
                </>
              )}
            </button>
            <Link
              href="/cart"
              className="block w-full text-center px-6 py-3 rounded-full border border-gold-500/40 text-gold-400 font-medium text-sm hover:bg-gold-500/10 transition-colors"
            >
              Zum Warenkorb
            </Link>
          </div>

          <div className="mt-10 pt-8 border-t border-gold-500/10 space-y-3 text-sm text-gray-500">
            <p>✓ Hochwertiger PLA-Druck</p>
            <p>✓ Made in Germany</p>
            <p>✓ Versandfertig in 2–4 Werktagen</p>
          </div>
        </div>
      </div>
    </div>
  );
}
