"use client";

import { useSearchParams } from "next/navigation";
import { useMemo, Suspense } from "react";
import ProductCard from "@/components/ProductCard";
import { products, categories } from "@/lib/products";
import Link from "next/link";

function ProductsContent() {
  const searchParams = useSearchParams();
  const activeCategory = searchParams.get("category") || "Alle";

  const filtered = useMemo(() => {
    if (activeCategory === "Alle") return products;
    return products.filter((p) => p.category === activeCategory);
  }, [activeCategory]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 md:py-14">
      {/* Header */}
      <div className="mb-10">
        <h1 className="text-3xl md:text-4xl font-bold">
          Produkt<span className="gold-text">katalog</span>
        </h1>
        <p className="mt-2 text-gray-400 text-sm">
          {filtered.length} Produkt{filtered.length !== 1 ? "e" : ""} gefunden
        </p>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-2 mb-10">
        {categories.map((cat) => {
          const isActive = activeCategory === cat;
          return (
            <Link
              key={cat}
              href={cat === "Alle" ? "/products" : `/products?category=${cat}`}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                isActive
                  ? "bg-gold-500 text-dark-950 shadow-gold"
                  : "bg-dark-900/60 text-gray-400 border border-gold-500/20 hover:border-gold-500/40 hover:text-gold-300"
              }`}
            >
              {cat}
            </Link>
          );
        })}
      </div>

      {/* Grid */}
      {filtered.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filtered.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      ) : (
        <div className="text-center py-20">
          <p className="text-gray-500">Keine Produkte in dieser Kategorie.</p>
          <Link
            href="/products"
            className="mt-4 inline-block text-gold-400 hover:text-gold-300 text-sm"
          >
            Alle Produkte anzeigen
          </Link>
        </div>
      )}
    </div>
  );
}

export default function ProductsPage() {
  return (
    <Suspense
      fallback={
        <div className="max-w-7xl mx-auto px-4 py-20 text-center text-gray-500">
          Lade Katalog…
        </div>
      }
    >
      <ProductsContent />
    </Suspense>
  );
}
