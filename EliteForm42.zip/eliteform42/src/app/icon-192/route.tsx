import { ImageResponse } from "next/og";

export const runtime = "edge";

export async function GET() {
  return new ImageResponse(
    (
      <div
        style={{
          width: "100%",
          height: "100%",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          background: "#0a0a0a",
        }}
      >
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
          }}
        >
          <div style={{ fontSize: 56, fontWeight: 700, color: "#c9a227" }}>
            EF
          </div>
          <div
            style={{
              fontSize: 22,
              fontWeight: 600,
              color: "#e0b85a",
              letterSpacing: 4,
            }}
          >
            42
          </div>
        </div>
      </div>
    ),
    { width: 192, height: 192 }
  );
}
