"use client";

import Link from "next/link";
import { useCartStore } from "@/store/cart";
import { useEffect, useState } from "react";
import { CheckCircle, ArrowLeft } from "lucide-react";

export default function CheckoutPage() {
  const { items, totalPrice, clearCart } = useCartStore();
  const [mounted, setMounted] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  if (!mounted) {
    return (
      <div className="max-w-xl mx-auto px-4 py-20 text-center text-gray-500">
        Lade…
      </div>
    );
  }

  if (items.length === 0 && !submitted) {
    return (
      <div className="max-w-xl mx-auto px-4 py-20 text-center">
        <p className="text-gray-400 mb-6">Dein Warenkorb ist leer.</p>
        <Link
          href="/products"
          className="text-gold-400 hover:text-gold-300 text-sm"
        >
          Zurück zum Katalog
        </Link>
      </div>
    );
  }

  if (submitted) {
    return (
      <div className="max-w-xl mx-auto px-4 py-20 text-center">
        <CheckCircle className="w-16 h-16 mx-auto text-gold-400 mb-6" />
        <h1 className="text-2xl font-bold mb-2">Vielen Dank!</h1>
        <p className="text-gray-400 mb-2">
          Deine Bestellung wurde (simuliert) aufgegeben.
        </p>
        <p className="text-sm text-gray-500 mb-8">
          Die Antwort ist und bleibt 42.
        </p>
        <Link
          href="/products"
          className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-gold-500 text-dark-950 font-semibold text-sm hover:bg-gold-400 transition-colors"
        >
          Weiter einkaufen
        </Link>
      </div>
    );
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    clearCart();
  };

  return (
    <div className="max-w-xl mx-auto px-4 sm:px-6 py-10 md:py-14">
      <Link
        href="/cart"
        className="inline-flex items-center gap-2 text-sm text-gray-400 hover:text-gold-400 transition-colors mb-8"
      >
        <ArrowLeft className="w-4 h-4" />
        Zurück zum Warenkorb
      </Link>

      <h1 className="text-3xl font-bold mb-2">
        Check<span className="gold-text">out</span>
      </h1>
      <p className="text-sm text-gray-500 mb-10">
        Einfacher Demo-Checkout – keine echten Zahlungen.
      </p>

      {/* Order summary */}
      <div className="mb-8 p-5 rounded-2xl bg-dark-900/50 gold-border space-y-3">
        {items.map(({ product, quantity }) => (
          <div key={product.id} className="flex justify-between text-sm">
            <span className="text-gray-300">
              {product.name} × {quantity}
            </span>
            <span className="text-gold-400 font-medium">
              {(product.price * quantity).toFixed(2).replace(".", ",")} €
            </span>
          </div>
        ))}
        <div className="pt-3 border-t border-gold-500/20 flex justify-between font-semibold">
          <span>Gesamt</span>
          <span className="gold-text text-lg">
            {totalPrice().toFixed(2).replace(".", ",")} €
          </span>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-5">
        <div>
          <label className="block text-xs font-medium text-gray-400 mb-1.5">
            Name
          </label>
          <input
            type="text"
            required
            placeholder="Max Mustermann"
            className="w-full px-4 py-3 rounded-xl bg-dark-900 border border-gold-500/20 text-gray-100 placeholder:text-gray-600 focus:outline-none focus:border-gold-500/50 transition-colors"
          />
        </div>
        <div>
          <label className="block text-xs font-medium text-gray-400 mb-1.5">
            E-Mail
          </label>
          <input
            type="email"
            required
            placeholder="max@example.com"
            className="w-full px-4 py-3 rounded-xl bg-dark-900 border border-gold-500/20 text-gray-100 placeholder:text-gray-600 focus:outline-none focus:border-gold-500/50 transition-colors"
          />
        </div>
        <div>
          <label className="block text-xs font-medium text-gray-400 mb-1.5">
            Adresse
          </label>
          <input
            type="text"
            required
            placeholder="Musterstraße 42"
            className="w-full px-4 py-3 rounded-xl bg-dark-900 border border-gold-500/20 text-gray-100 placeholder:text-gray-600 focus:outline-none focus:border-gold-500/50 transition-colors"
          />
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-medium text-gray-400 mb-1.5">
              PLZ
            </label>
            <input
              type="text"
              required
              placeholder="12345"
              className="w-full px-4 py-3 rounded-xl bg-dark-900 border border-gold-500/20 text-gray-100 placeholder:text-gray-600 focus:outline-none focus:border-gold-500/50 transition-colors"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-gray-400 mb-1.5">
              Stadt
            </label>
            <input
              type="text"
              required
              placeholder="Berlin"
              className="w-full px-4 py-3 rounded-xl bg-dark-900 border border-gold-500/20 text-gray-100 placeholder:text-gray-600 focus:outline-none focus:border-gold-500/50 transition-colors"
            />
          </div>
        </div>

        <button
          type="submit"
          className="w-full mt-4 px-6 py-4 rounded-full bg-gold-500 text-dark-950 font-semibold text-sm hover:bg-gold-400 transition-colors shadow-gold"
        >
          Bestellung abschließen (Demo)
        </button>
      </form>
    </div>
  );
}
