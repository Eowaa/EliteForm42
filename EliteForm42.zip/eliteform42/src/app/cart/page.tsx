"use client";

import Link from "next/link";
import Image from "next/image";
import { useCartStore } from "@/store/cart";
import { Minus, Plus, Trash2, ShoppingBag, ArrowRight } from "lucide-react";
import { useEffect, useState } from "react";

export default function CartPage() {
  const { items, updateQuantity, removeItem, totalPrice, clearCart } =
    useCartStore();
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  if (!mounted) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-20 text-center text-gray-500">
        Lade Warenkorb…
      </div>
    );
  }

  if (items.length === 0) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-20 text-center">
        <ShoppingBag className="w-16 h-16 mx-auto text-gray-600 mb-6" />
        <h1 className="text-2xl font-bold mb-2">Dein Warenkorb ist leer</h1>
        <p className="text-gray-400 mb-8">
          Entdecke unsere humorvollen 3D-Drucke und füge etwas hinzu.
        </p>
        <Link
          href="/products"
          className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-gold-500 text-dark-950 font-semibold text-sm hover:bg-gold-400 transition-colors"
        >
          Zum Katalog
          <ArrowRight className="w-4 h-4" />
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10 md:py-14">
      <div className="flex items-center justify-between mb-10">
        <h1 className="text-3xl font-bold">
          Waren<span className="gold-text">korb</span>
        </h1>
        <button
          onClick={clearCart}
          className="text-xs text-gray-500 hover:text-red-400 transition-colors"
        >
          Alles leeren
        </button>
      </div>

      <div className="space-y-4">
        {items.map(({ product, quantity }) => (
          <div
            key={product.id}
            className="flex gap-4 p-4 rounded-2xl bg-dark-900/50 gold-border"
          >
            <div className="relative w-20 h-20 sm:w-24 sm:h-24 rounded-xl overflow-hidden bg-dark-800 flex-shrink-0">
              <Image
                src={product.image}
                alt={product.name}
                fill
                sizes="96px"
                className="object-cover"
                unoptimized
              />
            </div>
            <div className="flex-1 min-w-0">
              <Link
                href={`/products/${product.id}`}
                className="font-medium text-gray-100 hover:text-gold-300 transition-colors line-clamp-1"
              >
                {product.name}
              </Link>
              <p className="text-xs text-gray-500 mt-0.5">{product.category}</p>
              <p className="text-sm font-semibold text-gold-400 mt-2">
                {(product.price * quantity).toFixed(2).replace(".", ",")} €
              </p>
            </div>
            <div className="flex flex-col items-end justify-between">
              <button
                onClick={() => removeItem(product.id)}
                className="p-1.5 rounded-full text-gray-500 hover:text-red-400 hover:bg-red-500/10 transition-colors"
                aria-label="Entfernen"
              >
                <Trash2 className="w-4 h-4" />
              </button>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => updateQuantity(product.id, quantity - 1)}
                  className="w-8 h-8 flex items-center justify-center rounded-full border border-gold-500/30 text-gold-400 hover:bg-gold-500/10 transition-colors"
                >
                  <Minus className="w-3.5 h-3.5" />
                </button>
                <span className="w-6 text-center text-sm font-medium">
                  {quantity}
                </span>
                <button
                  onClick={() => updateQuantity(product.id, quantity + 1)}
                  className="w-8 h-8 flex items-center justify-center rounded-full border border-gold-500/30 text-gold-400 hover:bg-gold-500/10 transition-colors"
                >
                  <Plus className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Summary */}
      <div className="mt-10 p-6 rounded-2xl bg-dark-900/60 gold-border">
        <div className="flex justify-between items-center mb-6">
          <span className="text-gray-400">Zwischensumme</span>
          <span className="text-2xl font-bold gold-text">
            {totalPrice().toFixed(2).replace(".", ",")} €
          </span>
        </div>
        <p className="text-xs text-gray-500 mb-6">
          Versandkosten werden im Checkout berechnet.
        </p>
        <Link
          href="/checkout"
          className="flex items-center justify-center gap-2 w-full px-6 py-4 rounded-full bg-gold-500 text-dark-950 font-semibold text-sm hover:bg-gold-400 transition-colors shadow-gold"
        >
          Zur Kasse
          <ArrowRight className="w-4 h-4" />
        </Link>
      </div>
    </div>
  );
}
